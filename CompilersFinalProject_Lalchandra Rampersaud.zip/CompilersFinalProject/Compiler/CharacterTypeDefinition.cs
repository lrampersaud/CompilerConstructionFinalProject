﻿namespace CompilersFinalProject.Compiler
{
    public enum CharacterTypeDefinition
    {
        NULL = -1,
        DIGIT = 1,
        LETTER = 2,
        SPACE = 3,
        SYMBOL = 4
    }
}