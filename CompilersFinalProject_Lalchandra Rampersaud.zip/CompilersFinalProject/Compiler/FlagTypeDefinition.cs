﻿namespace CompilersFinalProject.Compiler
{
    public enum FlagTypeDefinition
    {
        Register = 1,
        Static = 2,
        Constant = 3,
        ReadOnly = 4
    }
}