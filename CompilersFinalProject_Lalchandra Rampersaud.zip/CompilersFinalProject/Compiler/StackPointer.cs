﻿namespace CompilersFinalProject.Compiler
{
    public struct StackPointer
    {
        int i;
        float f;
    }
}