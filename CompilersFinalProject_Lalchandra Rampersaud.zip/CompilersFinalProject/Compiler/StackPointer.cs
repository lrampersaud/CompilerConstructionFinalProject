﻿namespace CompilersFinalProject.Compiler
{
    public class StackPointer
    {
        public int i { get; set; }
        public float f { get; set; }
        public bool b { get; set; }
    }
}