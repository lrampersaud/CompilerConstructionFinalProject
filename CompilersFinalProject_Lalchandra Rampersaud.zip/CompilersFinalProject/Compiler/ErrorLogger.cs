﻿namespace CompilersFinalProject.Compiler
{
    public class ErrorLogger
    {

    }
}