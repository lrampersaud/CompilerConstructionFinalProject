﻿namespace CompilersFinalProject.Compiler

{
    public enum DataTypeDefinition
    {
        FALSE=0,
        TRUE = 1,
        TYPE_CHAR = 2,  //type char
        TYPE_INT = 3, //type int
        TYPE_FLOAT = 4,  //type float
        TYPE_VOID = 5, //type void
        TYPE_BOOL

    }
}