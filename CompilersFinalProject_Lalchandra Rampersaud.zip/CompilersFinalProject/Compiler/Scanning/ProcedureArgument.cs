﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompilersFinalProject.Compiler.Scanning
{
    public class ProcedureArgument
    {
        public string Name { get; set; }
        public DataTypeDefinition DataType { get; set; }
    }
}
